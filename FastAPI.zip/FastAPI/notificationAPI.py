import requests
import json
#import uvicorn
from fastapi import FastAPI,Request,HTTPException, status
from pydantic import BaseModel,HttpUrl,EmailStr
from typing import List,Union,Dict
#from fastapi_mail import FastMail, MessageSchema,ConnectionConfig
from starlette.requests import Request
from starlette.responses import JSONResponse
import pandas as pd
from tabulate import tabulate
import os
from fastapi.exceptions import RequestValidationError
from fastapi.responses import PlainTextResponse
from fastapi.encoders import jsonable_encoder
import traceback2 as traceback
import Failure_channel
from schema import Inc_Data, Inc_List

app=FastAPI()


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content=jsonable_encoder({
                 "ErrorMessage": {"You are missing some parameter"}}),
    )


def notify(detail):
     try:


          response= requests.post("http://127.0.0.1:9000/api/v1/notifyuserteams", data=detail)          
          print(response.json())

     except Exception as err:

        teams_err = "Failed to Establish connection with Teams"
        Failure_channel.Failed_notification(teams_err)  
        traceback.print_exception(None, err, err.__traceback__)
        raise HTTPException(status_code=404,detail="Error while sending post request to Teams API: " + str(err))

     #################### slack notify #####################
     try:
          response= requests.post("http://127.0.0.1:9002/api/v1/notifyuserslack", data=detail)
          print(response.json())

     except Exception as err:

        slack_err = "Failed to Establish connection with Slack"
        Failure_channel.Failed_notification(slack_err)
        traceback.print_exception(None, err, err.__traceback__)
        raise HTTPException(status_code=404,detail="Error while sending post request to Slack API: " + str(err))

     ########################## email notify #######################
     try:

          response= requests.post("http://127.0.0.1:9003/api/v1/notifyuseremails", data=detail)
          print(response.json())

     except Exception as err:

        email_err = "Failed to Establish connection with Email"
        Failure_channel.Failed_notification(email_err)
        traceback.print_exception(None, err, err.__traceback__)
        raise HTTPException(status_code=404,detail="Error while sending post request to Email API: " + str(err))


######################################## post schema request to get response ############################

@app.post("/api/v1/check_receive")
async def received(res_data: Inc_List):
       
     json_compatible_item_data = jsonable_encoder(res_data)
     detail=json.dumps(json_compatible_item_data)
     notify(detail)
     
     return{
          "message": "data received"
     }

