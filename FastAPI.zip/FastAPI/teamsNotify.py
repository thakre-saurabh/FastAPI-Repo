import pymsteams
import uvicorn
from fastapi import FastAPI,Request,HTTPException
from pydantic import BaseModel,HttpUrl,EmailStr
from typing import List,Union
#from fastapi_mail import FastMail, MessageSchema,ConnectionConfig
from starlette.requests import Request
from starlette.responses import JSONResponse
import requests, json
import pandas as pd
from tabulate import tabulate
#import snow
import traceback2 as traceback
#from test1 import get_data
import processTable
from fastapi.encoders import jsonable_encoder
from fastapi.responses import PlainTextResponse
import Failure_channel
from schema import Inc_List


app=FastAPI()
   
   
@app.post('/api/v1/notifyuserteams', tags=['TicketDetails'])
def teams_notify_user(payload:Inc_List):
    
    json_compatible_item_data = jsonable_encoder(payload)
    #print(json_compatible_item_data)
    ex=processTable.get_data(**json_compatible_item_data)
    #ex2=ex.to_html()
    
    try:

        myTeamsMessage = pymsteams.connectorcard("https://hclo365.webhook.office.com/webhookb2/132903f3-115c-4c85-89dd-2a8c55e52d21@189de737-c93a-4f5a-8b68-6f4ca9941912/IncomingWebhook/431976800fe64b2485edd6e96126c4e7/8e9e301b-b64d-47ad-82e9-49e70d8a8aff")
        #print(len(ex))
    
        for i in range(len(ex['Number'])):

            myMessageSection=None
            myMessageSection = pymsteams.cardsection()

            #a=ex['Number'][i]

            myMessageSection.addFact("Number",ex['Number'][i])
            myMessageSection.addFact("Sys_id",ex['Sys_id'][i])
            myMessageSection.addFact("Assignment_Group",ex['assignment_group'][i])
            myMessageSection.addFact("State",ex['State'][i])
            myMessageSection.addFact("Short_description",ex['Short_description'][i])
            myMessageSection.addFact("Priority",ex['Priority'][i])
            myMessageSection.addFact("Opened_at",ex['Opened_At'][i])
            myTeamsMessage.text("Notification System Alert")


            # Add your section to the connector card object before sending
            myTeamsMessage.addSection(myMessageSection)

        # Then send the card
        myTeamsMessage.send()

        ex1="User notified over Teams notification channel"
        print(ex1)
        #return "message delivered"
    
    #teams_notify_user()

    except Exception as err:

        teams_err = "Failed to Establish connection with Teams"
        Failure_channel.Failed_notification(teams_err)
        #print(str(err))
        traceback.print_exception(None, err, err.__traceback__)
        print(err.__traceback__)
        raise HTTPException(status_code=404,detail="Error while notifying Teams: " + str(err))

    return {"message" :" teams notified"}

   
 
#teams_notify_user(fetch1)