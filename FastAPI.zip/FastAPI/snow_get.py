from fastapi import FastAPI, HTTPException
import uvicorn
from pydantic import BaseModel
import requests, json
from datetime import datetime, timedelta, date
from fastapi.encoders import jsonable_encoder
from typing import List
import traceback2 as traceback
import Failure_channel
import os


to_date = date.today()
to_time = (datetime.now()).strftime("%H:%M:%S")
from_date = to_date - timedelta(days=1)
from_time = (datetime.now() - timedelta(hours=24)).strftime("%H:%M:%S")

app = FastAPI()
    

def db_post(json_data):

    #PostRequesttoDB
    try:
        
        db = requests.post("http://127.0.0.1:6000/api/v1/notifyuser/db", data = json_data)
        print(db.json())

    except Exception as err:

        db_err = "Failed to Establish connection with DB"
        Failure_channel.Failed_notification(db_err)
        traceback.print_exception(None, err, err.__traceback__)
        raise HTTPException(status_code=404,detail="Error while sending post request to DB: " + str(err))

    #PostRequesttoNotifyAPI
    try:

        if db.status_code == 200:
            notify_res= requests.post("http://127.0.0.1:8000/api/v1/check_receive", data = json_data)
            print(notify_res.json())

    except Exception as err:

        receive_err = "Failed to Establish connection with NotifyAPI"
        Failure_channel.Failed_notification(receive_err)
        traceback.print_exception(None, err, err.__traceback__)
        raise HTTPException(status_code=404,detail="Error while sending post request to NotifyAPI: " + str(err))
    

@app.get('/api/v1/notifyuser/fetch')#, tags=['Incidents'])
async def get_incidents():
    
    Inc_List={'it': []}

    #FetchingTicketsFromSNOW
    try:

        url =f"""https://dev106584.service-now.com/api/now/table/incident?sysparm_query=active%3Dtrue%5Eassignment_group%3D287ee6fea9fe198100ada7950d0b1b73%5Eopened_atBETWEENjavascript%3Ags.dateGenerate('{from_date}'%2C'{from_time}')%40javascript%3Ags.dateGenerate('{to_date}'%2C'{to_time}')%5Estate%3D1&sysparm_fields=number,assignment_group,state,sys_id,short_description,priority,opened_at&sysparm_display_value=true"""

        user = os.environ.get("user_name")
        #'admin'
        pwd = os.environ.get("user_password")
        #'PJkJZ-cx8!d5'
        

        headers = {"Content-Type":"application/json","Accept":"application/json"}
        response = requests.get(url, auth=(user, pwd), headers=headers )

        data = response.json()

        if response.status_code != 200: 
            print('Status:', response.status_code, 'Headers:', response.headers, 'Error Response:',response.json())
            exit()
    
        parse_json = data['result']
        
        
        for i in range(len(data['result'])):
            dict1={

                    'number':data['result'][i]['number'],
                    'sys_id':data['result'][i]['sys_id'],
                    'short_description':data['result'][i]['short_description'],
                    'assignment_group':data['result'][i]['assignment_group']['display_value'],
                    'state':data['result'][i]['state'],
                    'priority':data['result'][i]['priority'],
                    'opened_at':data['result'][i]['opened_at']  
                 }
            Inc_List['it'].append(dict1)

        
        json_compatible_item_data = jsonable_encoder(Inc_List)
        check = json.dumps(json_compatible_item_data)
        

        if len(parse_json)>0:
            db_post(check)

        else:
            print("No data Found") 
            return None  
       
    
    except Exception as err:

        Snow_err = "Failed to Establish connection with SNOW"
        Failure_channel.Failed_notification(Snow_err)
        traceback.print_exception(None, err, err.__traceback__)
        raise HTTPException(status_code=404,detail="Error with SNOW: " + str(err))
    
 
get_incidents()

