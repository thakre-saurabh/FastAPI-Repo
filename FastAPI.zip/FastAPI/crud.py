from sqlalchemy.orm import Session
import model

#print("start call")

def read_data(db: Session, sys_id: str):
    #print("calling")
    found_data = True
    found_data = db.query(model.Incident).filter(model.Incident.sys_id == sys_id).first()
    return found_data
    
