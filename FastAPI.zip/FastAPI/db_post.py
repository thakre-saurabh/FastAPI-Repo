from fastapi import FastAPI, Depends, APIRouter, Request, HTTPException, status
#from starlette.responses import RedirectResponse
import requests
import json
import snow_get
from pydantic import BaseModel
from typing import List
from fastapi.encoders import jsonable_encoder
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse
from database import engine, SessionLocal
from sqlalchemy.orm import Session
from model import Incident
import model, crud 
from schema import Inc_List

model.Base.metadata.create_all(bind=engine)

#router = APIRouter()
app = FastAPI()

#dependency
def get_db():
    db=SessionLocal()
    try:
        yield db
    finally:
        db.close


@app.exception_handler(RequestValidationError)
async def validation_exception_handler(request: Request, exc: RequestValidationError):
    return JSONResponse(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        content=jsonable_encoder({
                 "ErrorMessage": {"You are missing some parameter"}}),
    )


@app.post('/api/v1/notifyuser/db', tags=['TicketDetails'])  #response_model=str, 
async def post_data(incidents: Inc_List, db: Session = Depends(get_db)): 

    for item_data in incidents.it:
            
        inc = Incident(sys_id =item_data.sys_id, number = item_data.number, assignment_group=item_data.assignment_group ,short_description= item_data.short_description, state=item_data.state, priority=item_data.priority, opened_at=item_data.opened_at)
        res = crud.read_data(db, sys_id = inc.sys_id)

        if res:

            #raise HTTPException(status_code=400, detail="SysId already in DB") 
            print("ErrorMessage: SysId already in DB")
            
        else:
            db.add(inc)         
        #db.refresh(inc)

    db.commit()
    return{
        "Message": "Data added to DB Successfully"
    }


    # for item in d:
    #     inc = Incident(sys_id=item.get('sys_id'), number= item.get('number'), assignment_group= (item.get('assignment_group')).get('display_value'), short_description= item.get('short_description'), state= item.get('state'))
    #     res = crud.read_data(db, sys_id = inc.sys_id)
    #     if res:
    #         raise HTTPException(status_code=400, detail="SysId already in DB")
    #     db.add(inc)

    
    
    
    
    

    







    




