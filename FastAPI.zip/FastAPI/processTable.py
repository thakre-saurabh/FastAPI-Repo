from typing import Union
from tabulate import tabulate
import pandas as pd
from fastapi import APIRouter, FastAPI
from pydantic import BaseModel, HttpUrl
#ab={'it': [{'number': 'string', 'assignment_group': 'string', 'short_description': 'string', 'state': 'string'}, {'number': 'string', 'assignment_group': 'string', 'short_description': 'string', 'state': 'string'}]}


def get_data(**Incident_result):
     #detail={}
    # json_compatible_item_data = jsonable_encoder(Incident_result)
    # detail=json_compatible_item_data
    global df1
    User_Details = {"Sys_id":[],"Number":[],"Short_description":[],"assignment_group":[],"State":[],"Opened_At":[],"Priority":[]};
    for i in range(len(Incident_result['it'])):

        inc_num = Incident_result['it'][i]['number']
        sys_id = Incident_result['it'][i]['sys_id']
        short_desc = Incident_result['it'][i]['short_description']
        assign = Incident_result['it'][i]['assignment_group']
        st = Incident_result['it'][i]['state']
        priority = Incident_result['it'][i]['priority']
        opened_at = Incident_result['it'][i]['opened_at']

        User_Details['Number'].append(inc_num)
        User_Details['Sys_id'].append(sys_id)
        User_Details['Short_description'].append(short_desc)
        User_Details['assignment_group'].append(assign)
        User_Details['State'].append(st)
        User_Details['Opened_At'].append(opened_at)
        User_Details['Priority'].append(priority)

    #df1=pd.DataFrame(User_Details)
        #df1=df.to_html()
    #df1=(tabulate(df, headers = 'keys', tablefmt = 'github'))
    #print(df1)
    #print(User_Details)

    return User_Details
#get_data(**ab)