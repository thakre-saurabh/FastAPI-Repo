from database import Base
from sqlalchemy import Column, Integer, String


class Incident(Base):
    __tablename__ = "tblIncidents1"
    sys_id = Column(String, primary_key=True, index=True)
    number = Column(String)
    assignment_group = Column(String)
    short_description = Column(String)
    state = Column(String) 
    priority = Column(String)
    opened_at = Column(String)
    