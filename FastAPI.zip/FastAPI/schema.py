from pydantic import BaseModel
from typing import List


class Inc_Data(BaseModel):
    sys_id: str
    number: str
    assignment_group: str
    short_description: str
    state: str
    priority: str
    opened_at: str

    class Config:
        orm_mode =True

class Inc_List(BaseModel):
    it: List[Inc_Data]



    
        

    